import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {HttpClient, HttpHeaders} from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent implements OnInit {
  userForm: FormGroup;
/*   firstName: string;
  lastName: string;
  email: string;
  password: string; */
  constructor(private formBuilder: FormBuilder, private httpClient: HttpClient) { }

  ngOnInit() {
    this.userForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('^[a-zA-z]+$')]],
      lastName: ['', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    }, {
        validator: StrengthValidator('password')
    });
  }
  get user() { return this.userForm.controls; }
  onSubmit() {
    const headers = new HttpHeaders()
          .set('Authorization', 'my-auth-token')
          .set('Content-Type', 'application/json');
    if (this.userForm.valid) {
 /*      alert('good'); */
    this.httpClient.post('http://10.142.157.39:3000/api/userCreate', this.userForm.value)
      .subscribe((response) => {
        console.log('repsonsei ', response);
      });
    } else {
      alert('not good');
    }
  }

}
export function StrengthValidator(controlName: string) {
    return (formGroup: FormGroup) => {
      const strengthController = formGroup.controls[controlName];
      const lowercaseRegex = new RegExp('(?=.*[a-z])');
      const uppercaseRegex = new RegExp('(?=.*[A-Z])');
      const numRegex = new RegExp('(?=.*\\d)');
      const specialcharRegex = new RegExp('[!@#$%^&*(),.?\":{}|<>]');

      if (strengthController.errors) {
                return;
          }
      if (!(lowercaseRegex.test(strengthController.value))) {
        strengthController.setErrors({hasSmallCase: true});
      }
      if (!(uppercaseRegex.test(strengthController.value))) {
        strengthController.setErrors({hasCapCase: true});
      }
      if (!(numRegex.test(strengthController.value))) {
        strengthController.setErrors({hasNumericCase: true});
      }
      if (!(specialcharRegex.test(strengthController.value))) {
        strengthController.setErrors({hasSpecialCase: true});
      }
    };
}
